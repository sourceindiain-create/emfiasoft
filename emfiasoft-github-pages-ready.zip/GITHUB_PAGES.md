# GitHub Pages Deployment

GitHub Pages can host the static frontend of this project for free.

## Free GitHub Pages URL

After uploading this project to GitHub and enabling Pages, the free URL will look like:

```text
https://YOUR_GITHUB_USERNAME.github.io/REPOSITORY_NAME/
```

For example:

```text
https://YOUR_GITHUB_USERNAME.github.io/emfiasoft/
```

## Custom Domain

This project includes:

```text
CNAME
```

with:

```text
emfiasoft.io
```

To use `https://emfiasoft.io`, you must first buy the `emfiasoft.io` domain from a domain registrar. Then add GitHub Pages DNS records at the registrar.

## Dynamic Backend Note

GitHub Pages is static hosting only. It cannot run `server.js`.

For dynamic backend routes like `/api/courses`, `/api/students`, `/api/payments`, and `/api/contacts`, keep using one of these:

- Local backend: `http://127.0.0.1:4173/`
- Cloudflare Workers
- Firebase App Hosting or Cloud Functions
- Render / Railway / VPS

The frontend can be on GitHub Pages while the API lives on one of those backend hosts.
