# EMF Global Technology & Research

Static frontend and local full-stack prototype for EMF Global Technology & Research / Glossary Soft Tech Pvt. Ltd.

## Live Static Hosting

- Firebase: https://emfglballive-live.web.app/
- Firebase alternate: https://emfglballive-live.firebaseapp.com/

## GitHub Pages

This repository is ready for GitHub Pages using `.github/workflows/pages.yml`.

Expected GitHub Pages URL:

```text
https://YOUR_GITHUB_USERNAME.github.io/emfiasoft/
```

If the custom domain `emfiasoft.io` is purchased and DNS is configured, GitHub Pages can serve:

```text
https://emfiasoft.io
```

## Dynamic Backend

GitHub Pages is static hosting and cannot run `server.js`.

Run the local full-stack app:

```bash
node server.js
```

Open:

```text
http://127.0.0.1:4173/
```
