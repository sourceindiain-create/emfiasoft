/* ==================== EMF MULTILINGUAL VOICE & OCR AI CHATBOT ==================== */

// Chatbot UI State
let isChatbotOpen = false;
let chatLanguage = "en"; // en, te, hi
let isSpeechEnabled = true;
let recognition = null;
let currentVoice = null;

// Multilingual Mock AI Knowledge Engine (Fallback when no Gemini Key)
const OFFLINE_KNOWLEDGE = {
    en: {
        welcome: "Hello! I am your EMF Global AI Assistant. How can I help you today with our IT, Technology, and Biotech systems?",
        default: "That is an excellent inquiry! As part of EMF Global Technology (Glossary Soft Tech Pvt. Ltd.), we support full certification and 1-Year Career Support across all streams. Would you like to know about our Drone courses, AI/ML programs, EV systems, or our Agri-Biotech incubation hubs?",
        courses: "We offer courses in IT & AI (Data Science, AI/ML, IoT), Advanced Technology (Drones, Solar, EV, Green Hydrogen), Agri-Bio (Microgreens, Plant Development, Tissue Culture), and Commerce (Logistics, Investment Analysis). All courses include full-time certification and real-time experience.",
        drones: "Our Commercial Drone Technology course covers assembly, flight dynamics, programming, and thermal solar panels inspections. Fees: ₹5,500. Duration: 3 Months.",
        solar: "We provide state-of-the-art training in Solar & EV systems charging grids, battery chemistry, and smart grid systems. Fees: ₹5,000.",
        agri: "The Agri & Biotech Innovation Hub supports Plant Development, Tissue Culture, Water quality testing, microgreens production, and vertical vertical terrace farming. We develop over 100+ Acres of research zones.",
        fees: "Our dynamic training fees vary between ₹3,000 to ₹6,500. We also offer special startup incubation grants and scholarship options for deserving student researchers.",
        startups: "EMF supports company development with 1-Year incubation, product design, investor pitches, seed funding, and business registrations. You also get a Gold EMF Company Card absolutely FREE for 1 year!",
        ocr_result: "I have successfully analyzed your scanned document text: '{text}'. Based on this OCR data, I recommend exploring our specialized certification courses and smart industrial tools to achieve your professional career goals!"
    },
    te: {
        welcome: "నమస్కారం! నేను మీ EMF గ్లోబల్ AI అసిస్టెంట్. ఐటి, టెక్నాలజీ మరియు బయోటెక్ సిస్టమ్స్ గురించి మీకు ఎలా సహాయపడగలను?",
        default: "చాలా మంచి ప్రశ్న! EMF గ్లోబల్ టెక్నాలజీ (గ్లోసరీ సాఫ్ట్ టెక్ ప్రైవేట్ లిమిటెడ్) లో భాగముగా, మేము అన్ని విభాగాలలో పూర్తి ధృవీకరణ మరియు 1-సంవత్సరం కెరీర్ మద్దతును అందిస్తాము. మీరు మా డ్రోన్ కోర్సులు, AI/ML ప్రోగ్రామ్‌లు, EV సిస్టమ్స్ లేదా అగ్రి-బయోటెక్ ఇంక్యుబేషన్ హబ్‌ల గురించి తెలుసుకోవాలనుకుంటున్నారా?",
        courses: "మేము ఐటి & AI (డేటా సైన్స్, AI/ML, IoT), అడ్వాన్స్డ్ టెక్నాలజీ (డ్రోన్స్, సోలార్, EV, గ్రీన్ హైడ్రోజన్), అగ్రి-బయో (మైక్రోగ్రీన్స్, ప్లాంట్ డెవలప్‌మెంట్, టిష్యూ కల్చర్), మరియు కామర్స్ కోర్సులను అందిస్తున్నాము. అన్ని కోర్సులు పూర్తి-సమయం ధృవీకరణను కలిగి ఉంటాయి.",
        drones: "మా కమర్షియల్ డ్రోన్ టెక్నాలజీ కోర్సు అసెంబ్లీ, ఫ్లైట్ డైనమిక్స్, ప్రోగ్రామింగ్ మరియు థర్మల్ సోలార్ ప్యానెల్ తనిఖీలను కవర్ చేస్తుంది. ఫీజు: ₹5,500. వ్యవధి: 3 నెలలు.",
        solar: "మేము సోలార్ & EV సిస్టమ్స్ ఛార్జింగ్ గ్రిడ్స్, బ్యాటరీ కెమిస్ట్రీ మరియు స్మార్ట్ గ్రిడ్ సిస్టమ్స్‌లో అత్యాధునిక శిక్షణను అందిస్తాము. ఫీజు: ₹5,000.",
        agri: "అగ్రి & బయోటెక్ ఇన్నోవేషన్ హబ్ ప్లాంట్ డెవలప్‌మెంట్, టిష్యూ కల్చర్, నీటి నాణ్యత పరీక్ష, మైక్రోగ్రీన్స్ ఉత్పత్తి మరియు నిలువు టెర్రస్ వ్యవసాయానికి మద్దతు ఇస్తుంది. మేము 100+ ఎకరాల పరిశోధనా జోన్‌లను అభివృద్ధి చేస్తున్నాము.",
        fees: "శిక్షణా ఫీజులు ₹3,000 నుండి ₹6,500 మధ్య ఉంటాయి. మేము అర్హులైన విద్యార్థి పరిశోధకులకు ప్రత్యేక స్టార్టప్ ఇంక్యుబేషన్ గ్రాంట్లు మరియు స్కాలర్‌షిప్ ఎంపికలను కూడా అందిస్తాము.",
        startups: "EMF 1-సంవత్సరం ఇంక్యుబేషన్, ప్రొడక్ట్ డిజైన్, ఇన్వెస్టర్ పిచ్‌లు, సీడ్ ఫండింగ్ మరియు వ్యాపార రిజిస్ట్రేషన్‌లతో కంపెనీ అభివృద్ధికి మద్దతు ఇస్తుంది. మీకు 1 సంవత్సరం పాటు ఉచితంగా గోల్డ్ EMF కంపెనీ కార్డ్ లభిస్తుంది!",
        ocr_result: "నేను మీ స్కాన్ చేసిన పత్రం టెక్స్ట్‌ని విజయవంతంగా విశ్లేషించాను: '{text}'. ఈ OCR డేటా ఆధారంగా, మీ వృత్తిపరమైన కెరీర్ లక్ష్యాలను సాధించడానికి మా ప్రత్యేక ధృవీకరణ కోర్సులు మరియు స్మార్ట్ పారిశ్రామిక సాధనాలను అన్వేషించాల్సిందిగా నేను సిఫార్సు చేస్తున్నాను!"
    },
    hi: {
        welcome: "नमस्ते! मैं आपका EMF ग्लोबल AI सहायक हूँ। आज मैं आईटी, प्रौद्योगिकी और बायोटेक प्रणालियों के बारे में आपकी क्या सहायता कर सकता हूँ?",
        default: "यह एक बहुत अच्छा सवाल है! EMF ग्लोबल टेक्नोलॉजी (ग्लोसरी सॉफ्ट टेक प्राइवेट लिमिटेड) के हिस्से के रूप में, हम सभी स्ट्रीम में पूर्ण प्रमाणन और 1-वर्षीय करियर सहायता प्रदान करते हैं। क्या आप हमारे ड्रोन पाठ्यक्रमों, AI/ML कार्यक्रमों, EV प्रणालियों, या हमारे कृषि-बायोटेक इनक्यूबेशन हब के बारे में जानना चाहते हैं?",
        courses: "हम आईटी और एआई (डेटा साइंस, एआई/एमएल, आईओटी), उन्नत प्रौद्योगिकी (ड्रोन, सोलर, ईवी, ग्रीन हाइड्रोजन), एग्री-बायो (माइक्रोग्रीन्स, प्लांट डेवलपमेंट, टिश्यू कल्चर), और कॉमर्स में पाठ्यक्रम प्रदान करते हैं। सभी पाठ्यक्रमों में पूर्णकालिक प्रमाणन शामिल है।",
        drones: "हमारा वाणिज्यिक ड्रोन प्रौद्योगिकी पाठ्यक्रम असेंबली, उड़ान गतिकी, प्रोग्रामिंग और थर्मल सोलर पैनल निरीक्षणों को कवर करता है। शुल्क: ₹5,500। अवधि: 3 महीने।",
        solar: "हम सोलर और ईवी सिस्टम चार्जिंग ग्रिड, बैटरी रसायन विज्ञान और स्मार्ट ग्रिड सिस्टम में अत्याधुनिक प्रशिक्षण प्रदान करते हैं। शुल्क: ₹5,000।",
        agri: "कृषि और बायोटेक नवाचार केंद्र संयंत्र विकास, ऊतक संवर्धन, जल गुणवत्ता परीक्षण, माइक्रोग्रीन्स उत्पादन और ऊर्ध्वाधर छत खेती का समर्थन करता है। हम 100+ एकड़ अनुसंधान क्षेत्रों का विकास कर रहे हैं।",
        fees: "हमारा प्रशिक्षण शुल्क ₹3,000 से ₹6,500 के बीच है। हम योग्य छात्र शोधकर्ताओं के लिए विशेष स्टार्टअप इनक्यूबेशन अनुदान और छात्रवृत्ति विकल्प भी प्रदान करते हैं।",
        startups: "EMF 1-वर्षीय इनक्यूबेशन, उत्पाद डिज़ाइन, निवेशक पिच, सीड फंडिंग और व्यावसायिक पंजीकरण के साथ कंपनी विकास का समर्थन करता है। आपको 1 वर्ष के लिए गोल्ड EMF कंपनी कार्ड बिल्कुल मुफ्त मिलता है!",
        ocr_result: "मैंने आपके स्कैन किए गए दस्तावेज़ टेक्स्ट का सफलतापूर्वक विश्लेषण किया है: '{text}'। इस ओसीआर डेटा के आधार पर, मैं आपके पेशेवर करियर लक्ष्यों को प्राप्त करने के लिए हमारे विशेष प्रमाणन पाठ्यक्रमों और स्मार्ट औद्योगिक उपकरणों का पता लगाने की सलाह देता हूँ!"
    }
};

// Toggle Chatbot Window open/close
function toggleChatbotWindow() {
    isChatbotOpen = !isChatbotOpen;
    const windowEl = document.getElementById("chatbot-window");
    if (!windowEl) return;
    
    if (isChatbotOpen) {
        windowEl.classList.add("active");
        // Focus chat input
        document.getElementById("chat-input-field").focus();
    } else {
        windowEl.classList.remove("active");
    }
}

// Language selector change handler
function changeChatLanguage() {
    const select = document.getElementById("chat-lang-select");
    if (!select) return;
    
    chatLanguage = select.value;
    
    // Add Welcome message in target language
    const welcomeMsg = OFFLINE_KNOWLEDGE[chatLanguage].welcome;
    appendMessage("system", welcomeMsg);
    speakSpeechText(welcomeMsg);
}

// Toggle voice speech output setting
function toggleVoiceSpeech() {
    isSpeechEnabled = !isSpeechEnabled;
    const btn = document.getElementById("btn-toggle-speech");
    if (!btn) return;
    
    if (isSpeechEnabled) {
        btn.innerHTML = `<i class="fa-solid fa-volume-high"></i>`;
        showToast("info", "Voice responses enabled");
    } else {
        btn.innerHTML = `<i class="fa-solid fa-volume-xmark"></i>`;
        window.speechSynthesis.cancel(); // Stop talking
        showToast("info", "Voice responses muted");
    }
}

// Start Speech-To-Text Voice recognition
function startVoiceInput() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        showToast("error", "Web Speech API (Speech Recognition) is not supported in this browser. Please type your message.");
        return;
    }

    if (recognition) {
        recognition.stop();
        return;
    }

    recognition = new SpeechRecognition();
    recognition.continuous = false;
    
    // Map language
    if (chatLanguage === "te") recognition.lang = "te-IN";
    else if (chatLanguage === "hi") recognition.lang = "hi-IN";
    else recognition.lang = "en-US";
    
    const micBtn = document.getElementById("chat-voice-btn");
    const waveEl = document.getElementById("chat-voice-wave");
    
    recognition.onstart = () => {
        micBtn.classList.add("recording");
        if (waveEl) waveEl.classList.remove("hidden");
        showToast("info", "Listening... Speak now.");
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        const inputField = document.getElementById("chat-input-field");
        if (inputField) {
            inputField.value = transcript;
            sendChatMessage();
        }
    };

    recognition.onerror = (event) => {
        console.error("STT Recognition Error:", event.error);
        showToast("error", `Voice recognition error: ${event.error}`);
        micBtn.classList.remove("recording");
        if (waveEl) waveEl.classList.add("hidden");
    };

    recognition.onend = () => {
        micBtn.classList.remove("recording");
        if (waveEl) waveEl.classList.add("hidden");
        recognition = null;
    };

    recognition.start();
}

// Speak out responses using Text-To-Speech
function speakSpeechText(text) {
    if (!isSpeechEnabled) return;
    
    // Cancel active synthesis first
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Select matched voice pack
    const voices = window.speechSynthesis.getVoices();
    
    let voiceLocale = "en-US";
    if (chatLanguage === "te") voiceLocale = "te-IN";
    if (chatLanguage === "hi") voiceLocale = "hi-IN";
    
    const matchedVoice = voices.find(v => v.lang.startsWith(voiceLocale));
    if (matchedVoice) {
        utterance.voice = matchedVoice;
    }
    
    // Slow pitch adjustment for clarity
    utterance.rate = 0.95;
    window.speechSynthesis.speak(utterance);
}

// Append Chat Bubbles to screen
function appendMessage(sender, text) {
    const chatContainer = document.getElementById("chat-messages");
    if (!chatContainer) return;
    
    const msg = document.createElement("div");
    msg.className = `message ${sender === "user" ? "user-msg" : "system-msg"}`;
    msg.innerText = text;
    
    chatContainer.appendChild(msg);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

// Send Text Query
async function sendChatMessage() {
    const inputField = document.getElementById("chat-input-field");
    if (!inputField) return;
    
    const query = inputField.value.trim();
    if (!query) return;
    
    appendMessage("user", query);
    inputField.value = "";
    
    // Append Thinking bubble
    const thinkingMsg = document.createElement("div");
    thinkingMsg.className = "message system-msg thinking-bubble";
    thinkingMsg.innerText = "Analyzing query...";
    document.getElementById("chat-messages").appendChild(thinkingMsg);
    
    try {
        const response = await queryAIChatbot(query);
        thinkingMsg.remove();
        appendMessage("system", response);
        speakSpeechText(response);
    } catch(err) {
        thinkingMsg.remove();
        appendMessage("system", "Apologies, I encountered a communication error with the neural gateway. Please check your internet connection.");
    }
}

// Handle keys in Chat Input field
function handleChatKeyPress(e) {
    if (e.key === "Enter") {
        sendChatMessage();
    }
}

// Trigger Client-Side OCR Scanner
function triggerChatOCR() {
    const fileInput = document.getElementById("chat-file-input");
    if (fileInput) fileInput.click();
}

// Process Image file through Tesseract.js In-Browser OCR
function processChatOcrImage(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        // Show preview inside chat
        const previewContainer = document.getElementById("chat-ocr-preview-container");
        const previewImg = document.getElementById("chat-ocr-image-preview");
        const statusText = document.getElementById("chat-ocr-status-text");
        const bar = document.getElementById("ocr-loading-bar");
        
        if (previewContainer && previewImg) {
            previewImg.src = e.target.result;
            previewContainer.classList.remove("hidden");
            bar.style.width = "0%";
            statusText.innerText = "Initializing OCR scanner engine...";
        }

        // Run Tesseract Optical Character Recognition
        Tesseract.recognize(
            file,
            chatLanguage === "te" ? "tel" : chatLanguage === "hi" ? "hin" : "eng",
            {
                logger: m => {
                    if (m.status === 'recognizing text') {
                        const progress = Math.round(m.progress * 100);
                        if (bar) bar.style.width = `${progress}%`;
                        if (statusText) statusText.innerText = `Analyzing layout: ${progress}%`;
                    }
                }
            }
        ).then(({ data: { text } }) => {
            if (bar) bar.style.width = "100%";
            if (statusText) statusText.innerText = "OCR scan completed!";
            
            setTimeout(() => {
                hideOcrPreview();
                
                const cleanedText = text.trim();
                if (!cleanedText) {
                    appendMessage("system", "OCR scan completed, but no legible text characters could be identified. Please ensure the image is clear and properly illuminated.");
                    return;
                }
                
                appendMessage("user", `[Scanned Document OCR]: "${cleanedText.substring(0, 150)}..."`);
                
                // Prompt engine
                const ocrPrompt = OFFLINE_KNOWLEDGE[chatLanguage].ocr_result.replace("{text}", cleanedText);
                appendMessage("system", ocrPrompt);
                speakSpeechText(ocrPrompt);
                
            }, 800);
        }).catch(err => {
            console.error("OCR Scan Error:", err);
            if (statusText) statusText.innerText = "OCR scanner failed. Try a smaller image.";
            showToast("error", "Failed to run in-browser OCR scanner.");
        });
    };
    reader.readAsDataURL(file);
}

function hideOcrPreview() {
    const previewContainer = document.getElementById("chat-ocr-preview-container");
    if (previewContainer) previewContainer.classList.add("hidden");
}

// Master AI Query Routing Logic (Gemini vs Fallback Knowledge)
async function queryAIChatbot(query) {
    const settings = db.getSettings();
    const apiKey = settings.geminiApiKey;
    
    if (apiKey && apiKey.trim() !== "") {
        // Real Google Gemini API calling
        return callRealGeminiAPI(query, apiKey);
    } else {
        // Highly reactive Local Search Fallback Engine
        return new Promise((resolve) => {
            setTimeout(() => {
                const lower = query.toLowerCase();
                const dict = OFFLINE_KNOWLEDGE[chatLanguage];
                
                if (lower.includes("course") || lower.includes("కోర్సు") || lower.includes("कोर्स") || lower.includes("study")) {
                    resolve(dict.courses);
                } else if (lower.includes("drone") || lower.includes("డ్రోన్") || lower.includes("उडान")) {
                    resolve(dict.drones);
                } else if (lower.includes("solar") || lower.includes("ev") || lower.includes("విద్యుత్")) {
                    resolve(dict.solar);
                } else if (lower.includes("agri") || lower.includes("వ్యవసాయం") || lower.includes("खेती") || lower.includes("farming") || lower.includes("biotech")) {
                    resolve(dict.agri);
                } else if (lower.includes("fee") || lower.includes("డబ్బులు") || lower.includes("शुल्क") || lower.includes("cost") || lower.includes("price")) {
                    resolve(dict.fees);
                } else if (lower.includes("startup") || lower.includes("కంపెనీ") || lower.includes("व्यापार") || lower.includes("business") || lower.includes("incubation")) {
                    resolve(dict.startups);
                } else {
                    resolve(dict.default);
                }
            }, 1000);
        });
    }
}

// Async API caller to Gemini 1.5 Flash Model
async function callRealGeminiAPI(query, apiKey) {
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
    
    // Inject system instructions so the model acts as the EMF assistant
    const systemPrompt = `You are the EMF Global Technology & Research (Glossary Soft Tech Pvt. Ltd.) AI Assistant.
    Answer questions precisely. You support courses in IT/AI (Data Science, AI/ML, IoT), Technology (Drones, Solar, EV, green hydrogen), and Agri-Biotech vertical vertical terrace farming (microgreens, water testing, terrace farming).
    You speak and respond in the language used by the user: English, Telugu (తెలుగు), or Hindi (हिन्दी).
    Keep responses friendly, helpful, and concise (under 4 sentences). Ensure your tone is highly professional.`;

    const requestBody = {
        contents: [
            {
                role: "user",
                parts: [
                    { text: systemPrompt },
                    { text: `User Language configuration: ${chatLanguage}. User question: ${query}` }
                ]
            }
        ]
    };

    const response = await fetch(endpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
        throw new Error("Failed to reach Gemini API");
    }

    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
}
