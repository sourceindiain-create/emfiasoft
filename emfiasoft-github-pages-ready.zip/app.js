/* ==================== EMF MASTER APPLICATION LOGIC ==================== */

// Global State
let currentRole = "web";
let currentPage = "home";
let currentStudent = DEFAULT_STUDENTS[0]; // Default user is Alex Mercer

// Initialize Application
document.addEventListener("DOMContentLoaded", async () => {
    await db.ready;
    renderCourses();
    populateEnrollmentDropdown();
    refreshDashboards();
    initStatsCounters();
    loadBrandLinks();
    
    // Auto active links in header
    window.addEventListener("hashchange", handleHashRouting);
    handleHashRouting();
});

// Load WhatsApp and Facebook Links
function loadBrandLinks() {
    const settings = db.getSettings();
    document.querySelectorAll(".wa-link").forEach(el => {
        el.href = settings.whatsapp;
    });
    document.querySelectorAll(".fb-link").forEach(el => {
        el.href = settings.facebook;
    });
}

// Router for Main Header Link clicks
function navigateTo(pageId) {
    currentPage = pageId;
    
    // Hide all sections in web container
    document.querySelectorAll("#view-web .page-section").forEach(sec => {
        sec.classList.remove("active");
    });
    
    // Show target section
    const targetSec = document.getElementById(`page-${pageId}`);
    if (targetSec) {
        targetSec.classList.add("active");
    }

    // Highlight active link
    document.querySelectorAll("#main-nav-links .nav-link").forEach(link => {
        link.classList.remove("active");
        if (link.getAttribute("href") === `#${pageId}`) {
            link.classList.add("active");
        }
    });

    // Make sure we are in web role
    switchRole("web");
}

// Handle Direct URLs with hash routing
function handleHashRouting() {
    const hash = window.location.hash.replace("#", "");
    if (hash && ["home", "courses", "agri-tech", "startups", "research", "contact"].includes(hash)) {
        navigateTo(hash);
    }
}

// Switch User Role Views
function switchRole(role) {
    currentRole = role;
    
    // Update role buttons
    document.querySelectorAll(".system-roles .role-btn").forEach(btn => {
        btn.classList.remove("active");
    });
    const activeBtn = document.getElementById(`btn-${role}-view`);
    if (activeBtn) activeBtn.classList.add("active");

    // Hide all role containers
    document.querySelectorAll(".app-container .role-container").forEach(con => {
        con.classList.remove("active");
    });

    // Show target container
    const targetCon = document.getElementById(`view-${role}`);
    if (targetCon) {
        targetCon.classList.add("active");
    }

    // If switching to admin or student, refresh data
    if (role === "student" || role === "admin") {
        refreshDashboards();
    }
    
    if (role === "flutter" && typeof initFlutterApp === "function") {
        initFlutterApp();
    }
}

// Render dynamic courses
function renderCourses(categoryFilter = "all") {
    const courses = db.getCourses();
    const container = document.getElementById("courses-container");
    if (!container) return;
    
    container.innerHTML = "";
    
    const filtered = categoryFilter === "all" 
        ? courses 
        : courses.filter(c => c.category === categoryFilter);
        
    filtered.forEach(course => {
        const ratingStars = "★".repeat(Math.round(course.rating)) + "☆".repeat(5 - Math.round(course.rating));
        const cardHtml = `
            <div class="course-card glass-card">
                <div class="course-card-header">
                    <span class="course-category">${course.category.toUpperCase()}</span>
                    <span class="course-rating" title="Rating: ${course.rating}/5">${ratingStars} ${course.rating}</span>
                </div>
                <h3 class="course-title">${course.title}</h3>
                <p class="course-desc">${course.description}</p>
                <div class="course-meta">
                    <span class="course-price">₹${course.fees.toLocaleString('en-IN')}</span>
                    <button class="enroll-btn" onclick="openEnrollmentModal('${course.title}')">Enroll <i class="fa-solid fa-lock"></i></button>
                </div>
            </div>
        `;
        container.innerHTML += cardHtml;
    });
}

// Course Tabs Filter
function filterCourses(category) {
    document.querySelectorAll(".course-tabs .tab-btn").forEach(btn => {
        btn.classList.remove("active");
        if (btn.innerText.toLowerCase().includes(category)) {
            btn.classList.add("active");
        }
    });
    
    // Special check for 'all'
    if (category === "all") {
        document.querySelectorAll(".course-tabs .tab-btn")[0].classList.add("active");
    }
    
    renderCourses(category);
}

// Populate course list inside enroll modal dropdown
function populateEnrollmentDropdown() {
    const select = document.getElementById("enroll-course-select");
    if (!select) return;
    
    select.innerHTML = "";
    const courses = db.getCourses();
    courses.forEach(c => {
        select.innerHTML += `<option value="${c.code}" data-fees="${c.fees}">${c.title} - ₹${c.fees.toLocaleString('en-IN')}</option>`;
    });
}

// Open / Close Enrollment Modal
function openEnrollmentModal(preSelectedCourseTitle = "") {
    populateEnrollmentDropdown();
    const select = document.getElementById("enroll-course-select");
    
    if (preSelectedCourseTitle && select) {
        // Find course code by title
        const courses = db.getCourses();
        const courseObj = courses.find(c => c.title === preSelectedCourseTitle);
        if (courseObj) {
            select.value = courseObj.code;
        }
    }
    
    updateEnrollmentFeesDisplay();
    
    // Show modal
    document.getElementById("enrollment-modal").classList.add("active");
}

function closeEnrollmentModal() {
    document.getElementById("enrollment-modal").classList.remove("active");
}

function updateEnrollmentFeesDisplay() {
    const select = document.getElementById("enroll-course-select");
    const display = document.getElementById("enrollment-fee-display");
    if (!select || !display) return;
    
    const selectedOption = select.options[select.selectedIndex];
    const fees = selectedOption ? selectedOption.getAttribute("data-fees") : "4500";
    display.innerText = `₹${parseInt(fees).toLocaleString('en-IN')}`;
}

// Handle Form Submission -> Trigger Payment Gateway Modal
function handleEnrollmentSubmit(e) {
    e.preventDefault();
    
    const name = document.getElementById("enroll-name").value;
    const email = document.getElementById("enroll-email").value;
    const phone = document.getElementById("enroll-phone").value;
    const select = document.getElementById("enroll-course-select");
    const branch = document.getElementById("enroll-branch").value;
    
    const courseCode = select.value;
    const courseTitle = select.options[select.selectedIndex].text.split(" - ")[0];
    const courseFees = parseInt(select.options[select.selectedIndex].getAttribute("data-fees"));
    
    closeEnrollmentModal();
    
    // Launch secure Razorpay payment modal
    triggerRazorpayPayment({
        name,
        email,
        phone,
        courseCode,
        courseTitle,
        fees: courseFees,
        branch
    });
}

// Toast Notifications Helper
function showToast(type, message) {
    const container = document.getElementById("toast-container");
    if (!container) return;
    
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    
    let icon = "info-circle";
    if (type === "success") icon = "circle-check";
    if (type === "error") icon = "triangle-exclamation";
    
    toast.innerHTML = `<i class="fa-solid fa-${icon}"></i> ${message}`;
    container.appendChild(toast);
    
    // Auto remove
    setTimeout(() => {
        toast.style.animation = "slideInRight 0.3s ease-out reverse";
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// Toggle light/dark themes
function toggleTheme() {
    const body = document.body;
    const icon = document.querySelector(".theme-toggle-btn i");
    
    if (body.classList.contains("light-theme")) {
        body.classList.remove("light-theme");
        body.classList.add("dark-theme");
        icon.className = "fa-solid fa-sun";
        showToast("info", "Dark theme activated");
    } else {
        body.classList.remove("dark-theme");
        body.classList.add("light-theme");
        icon.className = "fa-solid fa-moon";
        showToast("info", "Light theme activated");
    }
}

// Student Tab switcher
function switchDashTab(tabId) {
    document.querySelectorAll(".dash-nav-btn").forEach(btn => {
        btn.classList.remove("active");
    });
    
    // Highlight corresponding button
    event.currentTarget.classList.add("active");
    
    // Hide active tabs
    document.querySelectorAll(".dash-content .dash-tab").forEach(tab => {
        tab.classList.remove("active");
    });
    
    const targetTab = document.getElementById(`tab-${tabId}`);
    if (targetTab) targetTab.classList.add("active");
}

// Admin Tab switcher
function switchAdminTab(tabId) {
    document.querySelectorAll(".dash-sidebar .dash-nav-btn").forEach(btn => {
        btn.classList.remove("active");
    });
    
    event.currentTarget.classList.add("active");
    
    document.querySelectorAll(".dash-content .dash-tab").forEach(tab => {
        tab.classList.remove("active");
    });
    
    const targetTab = document.getElementById(`tab-${tabId}`);
    if (targetTab) targetTab.classList.add("active");
}

// Statistics increment animation
function initStatsCounters() {
    const counters = document.querySelectorAll(".stat-number");
    
    counters.forEach(counter => {
        const target = +counter.getAttribute("data-target");
        let count = 0;
        const increment = target / 50;
        
        const updateCount = () => {
            if (count < target) {
                count += increment;
                counter.innerText = Math.ceil(count) + (target === 5000 ? "+" : target === 125 ? "+" : "+");
                setTimeout(updateCount, 15);
            } else {
                counter.innerText = target + (target === 5000 ? "+" : "+");
            }
        };
        
        updateCount();
    });
}

// Refresh Portal Dashboards with DB Values
function refreshDashboards() {
    const students = db.getStudents();
    const payments = db.getPayments();
    const courses = db.getCourses();
    
    // 1. Student Dashboard Data
    const activeStudentPayments = payments.filter(p => p.studentEmail === currentStudent.email);
    const activeStudentEnrollments = students.filter(s => s.email === currentStudent.email);
    
    document.getElementById("student-name-display").innerText = currentStudent.name;
    document.getElementById("student-courses-count").innerText = activeStudentEnrollments.length;
    
    // Render enrolled courses inside Student dashboard
    const enrolledList = document.getElementById("student-courses-list");
    if (enrolledList) {
        enrolledList.innerHTML = "";
        if (activeStudentEnrollments.length === 0) {
            enrolledList.innerHTML = `<p style="grid-column: 1/-1; text-align: center; color: var(--text-muted);">No courses enrolled yet. Explore courses and register today!</p>`;
        }
        activeStudentEnrollments.forEach(enroll => {
            const courseObj = courses.find(c => c.code === enroll.courseCode);
            if (courseObj) {
                enrolledList.innerHTML += `
                    <div class="course-card glass-card">
                        <div class="course-card-header">
                            <span class="course-category">${courseObj.category.toUpperCase()}</span>
                            <span class="status-badge success">Active Study</span>
                        </div>
                        <h3 class="course-title">${courseObj.title}</h3>
                        <p class="course-desc">${courseObj.description}</p>
                        <div class="course-meta">
                            <span>Date: ${enroll.enrollDate}</span>
                            <button class="enroll-btn" style="background:#003087;" onclick="openCourseSyllabus('${courseObj.title}')">Study Portal <i class="fa-solid fa-play"></i></button>
                        </div>
                    </div>
                `;
            }
        });
    }

    // Render Student payments
    const paymentsTable = document.getElementById("student-payments-tbody");
    if (paymentsTable) {
        paymentsTable.innerHTML = "";
        activeStudentPayments.forEach(p => {
            paymentsTable.innerHTML += `
                <tr>
                    <td><code>${p.paymentId}</code></td>
                    <td>${p.courseTitle}</td>
                    <td><strong>₹${p.amount.toLocaleString('en-IN')}</strong></td>
                    <td><span class="status-badge success">Paid Secured</span></td>
                    <td>${p.timestamp}</td>
                    <td><button class="receipt-btn" onclick="downloadReceipt('${p.paymentId}')"><i class="fa-solid fa-download"></i> PDF</button></td>
                </tr>
            `;
        });
    }

    // Render certificates
    const certsList = document.getElementById("student-certs-list");
    if (certsList) {
        certsList.innerHTML = "";
        activeStudentEnrollments.forEach(enroll => {
            const courseObj = courses.find(c => c.code === enroll.courseCode);
            if (courseObj) {
                certsList.innerHTML += `
                    <div class="cert-card glass-card">
                        <i class="fa-solid fa-award cert-icon"></i>
                        <h3>${courseObj.title}</h3>
                        <p>Awarded to: <strong>${currentStudent.name}</strong></p>
                        <p>Date of Issue: ${enroll.enrollDate}</p>
                        <button class="btn-cert-download" onclick="downloadCert('${courseObj.title}', '${currentStudent.name}')"><i class="fa-solid fa-eye"></i> View Certificate</button>
                    </div>
                `;
            }
        });
    }

    // 2. Admin Dashboard Data
    document.getElementById("admin-total-students").innerText = students.length;
    document.getElementById("admin-total-courses").innerText = courses.length;
    
    const totalRev = payments.reduce((sum, p) => sum + p.amount, 0);
    document.getElementById("admin-total-revenue").innerText = `₹${totalRev.toLocaleString('en-IN')}`;

    // Render registrations table
    const adminOverviewTable = document.getElementById("admin-overview-tbody");
    if (adminOverviewTable) {
        adminOverviewTable.innerHTML = "";
        const latestRegs = [...students].reverse().slice(0, 5);
        latestRegs.forEach(reg => {
            const cObj = courses.find(c => c.code === reg.courseCode);
            adminOverviewTable.innerHTML += `
                <tr>
                    <td><strong>${reg.name}</strong></td>
                    <td>${reg.email}</td>
                    <td>${cObj ? cObj.title : reg.courseCode}</td>
                    <td><code>pay_LIVE_${Math.floor(Math.random()*1000000)}</code></td>
                    <td>${reg.enrollDate}</td>
                </tr>
            `;
        });
    }

    // Render admin manage courses
    const adminCoursesTable = document.getElementById("admin-courses-tbody");
    if (adminCoursesTable) {
        adminCoursesTable.innerHTML = "";
        courses.forEach(c => {
            adminCoursesTable.innerHTML += `
                <tr>
                    <td><code>${c.code}</code></td>
                    <td><strong>${c.title}</strong></td>
                    <td>${c.category.toUpperCase()}</td>
                    <td><strong>₹${c.fees.toLocaleString('en-IN')}</strong></td>
                    <td>${c.duration}</td>
                    <td><button class="receipt-btn" style="background:#ef4444;" onclick="deleteCourse('${c.code}')"><i class="fa-solid fa-trash"></i> Delete</button></td>
                </tr>
            `;
        });
    }

    // Render registrations in users tab
    const adminUsersTable = document.getElementById("admin-users-tbody");
    if (adminUsersTable) {
        adminUsersTable.innerHTML = "";
        students.forEach(s => {
            const cObj = courses.find(c => c.code === s.courseCode);
            adminUsersTable.innerHTML += `
                <tr>
                    <td><strong>${s.name}</strong></td>
                    <td>${s.email}</td>
                    <td>${s.phone}</td>
                    <td>${cObj ? cObj.title : s.courseCode}</td>
                    <td><span class="status-badge success">Enrolled</span></td>
                </tr>
            `;
        });
    }

    // Render admin payments received
    const adminPaymentsTable = document.getElementById("admin-payments-tbody");
    if (adminPaymentsTable) {
        adminPaymentsTable.innerHTML = "";
        payments.forEach(p => {
            adminPaymentsTable.innerHTML += `
                <tr>
                    <td><code>${p.paymentId}</code></td>
                    <td><strong>${p.studentName}</strong> (${p.studentEmail})</td>
                    <td>${p.courseTitle}</td>
                    <td><strong>₹${p.amount.toLocaleString('en-IN')}</strong></td>
                    <td><span class="status-badge success">${p.method}</span></td>
                    <td>${p.timestamp}</td>
                </tr>
            `;
        });
    }

    // Load admin settings inputs
    const settings = db.getSettings();
    const apiKeyInput = document.getElementById("gemini-api-key");
    const waInput = document.getElementById("config-whatsapp");
    const fbInput = document.getElementById("config-facebook");
    
    if (apiKeyInput) apiKeyInput.value = settings.geminiApiKey || "";
    if (waInput) waInput.value = settings.whatsapp;
    if (fbInput) fbInput.value = settings.facebook;
}

// Add New Course Form Modals
function openAddCourseModal() {
    document.getElementById("admin-course-modal").classList.add("active");
}

function closeAddCourseModal() {
    document.getElementById("admin-course-modal").classList.remove("active");
}

function handleNewCourseSubmit(e) {
    e.preventDefault();
    
    const code = document.getElementById("add-code").value;
    const title = document.getElementById("add-title").value;
    const category = document.getElementById("add-category").value;
    const fees = parseInt(document.getElementById("add-fees").value);
    const duration = document.getElementById("add-duration").value;
    const rating = parseFloat(document.getElementById("add-rating").value);
    const description = document.getElementById("add-description").value;
    
    const newCourse = { code, title, category, fees, duration, rating, description };
    
    db.saveCourse(newCourse);
    showToast("success", `New Course [${title}] created successfully!`);
    closeAddCourseModal();
    renderCourses();
    refreshDashboards();
}

// Delete Course
function deleteCourse(code) {
    db.deleteCourse(code);
    showToast("info", "Course deleted successfully");
    renderCourses();
    refreshDashboards();
}

// Save Admin Panel Settings
function saveAdminSettings() {
    const geminiApiKey = document.getElementById("gemini-api-key").value;
    const whatsapp = document.getElementById("config-whatsapp").value;
    const facebook = document.getElementById("config-facebook").value;
    
    db.saveSettings({ geminiApiKey, whatsapp, facebook });
    showToast("success", "Settings and AI Key configurations updated!");
    loadBrandLinks();
    refreshDashboards();
}

// Mock certificate preview download
function downloadCert(courseTitle, studentName) {
    showToast("info", `Opening high-resolution certificate modal for ${studentName}...`);
    alert(`
    ===================================================
                CERTIFICATE OF ACCOMPLISHMENT
    ===================================================
    This certifies that: ${studentName.toUpperCase()}
    has successfully completed the EMF ecosystem course:
    
            "${courseTitle.toUpperCase()}"
            
    with 1-Year Career Internship and real-time project.
    Co-powered by Glossary Soft Tech Pvt. Ltd. & Venus Products.
    ===================================================
    `);
}

// Mock PDF download
function downloadReceipt(payId) {
    showToast("success", `Receipt ${payId} PDF generated. Download starting...`);
}

// Open Mock course study syllabus
function openCourseSyllabus(title) {
    alert(`Launching Course Syllabus Viewer for "${title}". Starting Module 1: System Introduction and Workspace setup.`);
}

// Claim EMF Company Card
function claimCompanyCard() {
    showToast("success", "Your Gold Membership EMF Company Card has been registered! Access details sent to your registered email.");
}

// Contact form submit
function handleContactSubmit(e) {
    e.preventDefault();
    const name = document.getElementById("c-name").value;
    const email = document.getElementById("c-email").value;
    const subject = document.getElementById("c-subject").value;
    const message = document.getElementById("c-msg").value;

    db.saveContact({ name, email, subject, message });
    showToast("success", `Thank you, ${name}! Your request has been queued. An EMF support member will contact you shortly.`);
    document.getElementById("contact-form").reset();
}

// Helper to scroll to elements
function scrollToElement(id) {
    const el = document.getElementById(id);
    if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
    }
}

// ==================== NEW: SMART AI SEARCH SYSTEM ====================
function triggerGlobalAISearch() {
    const query = document.getElementById("global-ai-search").value.trim();
    if (!query) {
        showToast("error", "Please enter a search query!");
        return;
    }
    
    document.getElementById("global-ai-search").value = "";
    document.getElementById("search-query-display").innerText = `"${query}"`;
    
    // Perform simulated semantic lookup
    const lower = query.toLowerCase();
    const titleEl = document.getElementById("search-result-title");
    const descEl = document.getElementById("search-result-desc");
    const actionBtn = document.getElementById("search-actions");
    const actionBtnClick = document.getElementById("search-action-btn");
    
    actionBtn.classList.add("hidden");
    
    let title = "Search Results";
    let desc = "Searching our business databases...";
    let targetPage = "";
    
    if (lower.includes("drone") || lower.includes("flight") || lower.includes("uav")) {
        title = "Commercial Drone Technology (Tech Category)";
        desc = "Found: Drone assembly, solar panel thermal scans, and UAV telemetry programming. Highly recommended certification course at EMF Global.";
        targetPage = "courses";
    } else if (lower.includes("agri") || lower.includes("microgreen") || lower.includes("ph") || lower.includes("soil") || lower.includes("plant")) {
        title = "Agri & Biotech Innovation Hub";
        desc = "Found: 100+ Acres Smart Farming Zones, vertical microgreen plans, water pH calculators, and biotechnology tissue culture studies.";
        targetPage = "agri-tech";
    } else if (lower.includes("solar") || lower.includes("ev") || lower.includes("battery") || lower.includes("hydrogen")) {
        title = "Solar & EV Charging Grids";
        desc = "Found: Electric vehicle battery engineering, green hydrogen electrolyzers, and solar micro-grid synchronization projects.";
        targetPage = "courses";
    } else if (lower.includes("code") || lower.includes("compiler") || lower.includes("practice") || lower.includes("sandbox") || lower.includes("javascript")) {
        title = "Students Practice Hub & Labs";
        desc = "Found: JavaScript compilers, drone planning calculations, biotech testing simulators, and SWOT pitch scanners.";
        targetPage = "practice";
    } else if (lower.includes("partner") || lower.includes("link") || lower.includes("glossary") || lower.includes("venus") || lower.includes("email") || lower.includes("phone")) {
        title = "EMF Ecosystem Resources Directory";
        desc = "Found: Brand links, emails, office phone numbers, Skill India portal anchors, and Venus engineering contacts.";
        targetPage = "directory";
    } else if (lower.includes("startup") || lower.includes("company") || lower.includes("incubate") || lower.includes("funding")) {
        title = "Startup & Company Development Schemes";
        desc = "Found: 1-Year incubation packages, free EMF Company Gold Cards, seed pitches, and market launch assistance.";
        targetPage = "startups";
    } else {
        title = "General Search Solution";
        desc = `No direct course matched for "${query}". However, our AI chatbot suggests visiting our Brand Directory page or exploring our IT & AI courses for standard certifications.`;
        targetPage = "directory";
    }
    
    titleEl.innerText = title;
    descEl.innerText = desc;
    
    if (targetPage) {
        actionBtn.classList.remove("hidden");
        actionBtnClick.onclick = () => {
            closeSearchModal();
            navigateTo(targetPage);
        };
    }
    
    // Open Search Modal
    document.getElementById("search-modal").classList.add("active");
    
    // Synthesize Voice Speech for search result!
    if (typeof speakSpeechText === "function") {
        speakSpeechText(`Search completed. We found results related to: ${title}. ${desc}`);
    }
}

function closeSearchModal() {
    document.getElementById("search-modal").classList.remove("active");
}

function handleSearchKeyPress(e) {
    if (e.key === "Enter") {
        triggerGlobalAISearch();
    }
}

// ==================== NEW: STUDENTS PRACTICE TOOL SWITCHER ====================
function switchPracticeTool(toolId) {
    document.querySelectorAll(".practice-tabs .tab-btn").forEach(btn => {
        btn.classList.remove("active");
    });
    
    const activeBtn = document.getElementById(`pr-tab-${toolId}`);
    if (activeBtn) activeBtn.classList.add("active");
    
    document.querySelectorAll(".practice-tool-pane").forEach(pane => {
        pane.classList.remove("active");
    });
    
    const activePane = document.getElementById(`tool-${toolId}`);
    if (activePane) activePane.classList.add("active");
}

// 1. Practice Code Compiler logic
function runPracticeCode() {
    const code = document.getElementById("practice-code-input").value;
    const outputConsole = document.getElementById("practice-code-output");
    
    outputConsole.innerText = "Executing script...\n";
    
    // Save original console.log
    const oldLog = console.log;
    let logBuffer = [];
    
    console.log = function(...args) {
        logBuffer.push(args.map(a => typeof a === 'object' ? JSON.stringify(a) : a).join(' '));
    };
    
    try {
        // Run code dynamically
        const evalResult = eval(code);
        
        // Restore log
        console.log = oldLog;
        
        let output = logBuffer.join('\n');
        if (evalResult !== undefined) {
            output += `\n\nReturned value: ${evalResult}`;
        }
        
        outputConsole.innerText = output || "Code executed successfully. No console logs captured.";
        showToast("success", "Code compiled and executed!");
        
    } catch(err) {
        console.log = oldLog;
        outputConsole.innerText = `Runtime Error: ${err.message}`;
        showToast("error", "Code compilation failed!");
    }
}

function askAICodeHelp() {
    const code = document.getElementById("practice-code-input").value;
    
    // Focus chatbot
    toggleChatbotWindow();
    const chatInput = document.getElementById("chat-input-field");
    if (chatInput) {
        chatInput.value = `I am practicing Javascript in EMF console. Please debug or review my code: \n\n${code}`;
        showToast("info", "Code loaded into AI chatbot! Tap Send.");
    }
}

// 2. Drone & EV Simulation Planner calculations
function runDroneSimulation() {
    const cargo = parseFloat(document.getElementById("sim-drone-weight").value) || 0;
    const capacity = parseFloat(document.getElementById("sim-battery-kwh").value) || 0;
    const solarWatts = parseFloat(document.getElementById("sim-solar-watts").value) || 0;
    
    // Hover flight time calculation: base 45min decreases as cargo increases
    const hoverTime = Math.max(10, Math.round(45 - (cargo * 6)));
    
    // EV Road Range: Capacity times 7 + solar wattage helper bonus
    const roadRange = Math.round((capacity * 7.2) + (solarWatts * 0.15));
    
    document.getElementById("res-drone-time").innerText = `${hoverTime} Minutes`;
    document.getElementById("res-ev-range").innerText = `${roadRange} Kilometers`;
    
    showToast("info", "Recalculating Drone Flight drag and EV ranges...");
}

// 3. Biotech Nutrient pH calculator
function runBiotechAnalysis() {
    const ph = parseFloat(document.getElementById("sim-soil-ph").value) || 7;
    const turb = parseFloat(document.getElementById("sim-water-turb").value) || 0;
    
    const suitDisplay = document.getElementById("res-bio-suit");
    const adviceDisplay = document.getElementById("res-bio-advice");
    
    let suitability = "Optimal";
    let advice = "";
    
    if (ph < 5.5) {
        suitability = "Strongly Acidic (Dangerous)";
        advice = "Alert: Low pH disrupts microgreen cell walls. Inject agricultural lime (calcium carbonate) or organic potash minerals to raise pH closer to 6.5.";
        suitDisplay.style.color = "#ef4444";
    } else if (ph > 7.8) {
        suitability = "Strongly Alkaline (Poor)";
        advice = "Alert: High alkalinity locks soil iron compounds. Feed vertical soil channels with elemental sulfur or bio-composted leaves to restore organic acids.";
        suitDisplay.style.color = "#d97706";
    } else {
        suitability = "Neutral 6.5 (Highly Optimal)";
        advice = "Perfect: Excellent pH index! Optimal for Microgreens Vertical farming, Drip hydroponics, tomato, and organic terrace gardening.";
        suitDisplay.style.color = "var(--primary-green)";
    }
    
    if (turb > 15) {
        advice += " Also alert: High turbidity detected. Recommend standard water filtration grids to clear suspended organic particles.";
    }
    
    suitDisplay.innerText = suitability;
    adviceDisplay.innerText = advice;
    
    showToast("success", "Soil and Water biochemical diagnostics completed.");
}

// 4. Startup SWOT Idea Feasibility Scanner
function runStartupSwot() {
    const pitch = document.getElementById("swot-pitch").value.trim();
    if (!pitch) {
        showToast("error", "Please write your startup idea pitch first!");
        return;
    }
    
    const display = document.getElementById("swot-matrix-display");
    display.classList.remove("hidden");
    
    const strList = document.getElementById("swot-str");
    const weakList = document.getElementById("swot-weak");
    const oppList = document.getElementById("swot-opp");
    const thrList = document.getElementById("swot-thr");
    const scoreVal = document.getElementById("swot-score");
    
    strList.innerHTML = "";
    weakList.innerHTML = "";
    oppList.innerHTML = "";
    thrList.innerHTML = "";
    
    let strengths = ["Highly innovative value proposition", "Excellent digital scalability potential"];
    let weaknesses = ["High initial hardware R&D components capital", "Niche user target acquisition challenges"];
    let opportunities = ["Emerging eco-friendly green subsidy schemes", "Skill India incubator launch incentives"];
    let threats = ["Highly competitive tech frameworks market", "Strict battery EV/Drone local airspace regulations"];
    let score = "8.2/10";
    
    const lower = pitch.toLowerCase();
    if (lower.includes("drone") || lower.includes("solar")) {
        strengths.push("Direct alignment with EMF thermal drone solar patents");
        opportunities.push("Utilize Gramin Agri Seva smart research farming zones");
        score = "9.4/10";
        scoreVal.style.color = "var(--primary-green)";
    } else if (lower.includes("app") || lower.includes("software")) {
        strengths.push("Low raw material overhead, fast MVP development");
        weaknesses.push("Susceptible to server security breach issues");
        score = "8.7/10";
        scoreVal.style.color = "var(--primary-green)";
    } else {
        score = "7.8/10";
        scoreVal.style.color = "#d97706";
    }
    
    strengths.forEach(s => strList.innerHTML += `<li>${s}</li>`);
    weaknesses.forEach(w => weakList.innerHTML += `<li>${w}</li>`);
    opportunities.forEach(o => oppList.innerHTML += `<li>${o}</li>`);
    threats.forEach(t => thrList.innerHTML += `<li>${t}</li>`);
    
    scoreVal.innerText = score;
    showToast("success", "Startup SWOT enterprise modeling finished!");
}

// ==================== NEW: AI COURSE MATCHING ADVISOR SYSTEM ====================
function runAICourseRecommendation() {
    const interest = document.getElementById("ai-advisor-interest").value.trim();
    if (!interest) {
        showToast("error", "Please write down your career interests or goals first!");
        return;
    }
    
    const resultBox = document.getElementById("ai-advisor-result");
    const titleEl = document.getElementById("adv-res-title");
    const descEl = document.getElementById("adv-res-desc");
    const actionBtn = document.getElementById("adv-res-btn");
    
    resultBox.classList.remove("hidden");
    
    let matchedTitle = "";
    let matchedDesc = "";
    let matchedEnrollTitle = "";
    
    const lower = interest.toLowerCase();
    
    if (lower.includes("code") || lower.includes("program") || lower.includes("software") || lower.includes("web")) {
        matchedTitle = "Fullstack Web & Digital Marketing (BU-01) / AI & ML (IT-02)";
        matchedDesc = "Based on your coding goal, we highly recommend our Software programs. You will master fullstack architecture, dynamic database schemas, and digital scaling deployment.";
        matchedEnrollTitle = "Fullstack Web & Digital Marketing";
    } else if (lower.includes("drone") || lower.includes("uav") || lower.includes("fly") || lower.includes("flight")) {
        matchedTitle = "Commercial Drone Technology (TE-01)";
        matchedDesc = "For flight and aerial system interests, our commercial drone telemetry and solar panel survey certification is the ultimate choice.";
        matchedEnrollTitle = "Commercial Drone Technology";
    } else if (lower.includes("plant") || lower.includes("microgreen") || lower.includes("soil") || lower.includes("agri") || lower.includes("farming")) {
        matchedTitle = "Smart Biotech & Plant Development (AG-01)";
        matchedDesc = "For agriculture and biotech goals, we match you with our smart vertical vertical microgreen models and laboratory tissue culture programs.";
        matchedEnrollTitle = "Smart Biotech & Plant Development";
    } else if (lower.includes("solar") || lower.includes("ev") || lower.includes("car") || lower.includes("battery") || lower.includes("hydrogen")) {
        matchedTitle = "Solar & EV Systems Engineering (TE-02)";
        matchedDesc = "For sustainable engineering and battery goals, our electric vehicle grids and solar array synchronization certificates represent your best career alignment.";
        matchedEnrollTitle = "Solar & EV Systems Engineering";
    } else if (lower.includes("business") || lower.includes("analyt") || lower.includes("finance") || lower.includes("money") || lower.includes("account")) {
        matchedTitle = "Tally ERP & Business Analytics (BU-02)";
        matchedDesc = "For financial accounting and logistics goals, our corporate ERP and database management dashboard training will accelerate your career paths.";
        matchedEnrollTitle = "Tally ERP & Business Analytics";
    } else {
        matchedTitle = "Artificial Intelligence & ML (IT-02)";
        matchedDesc = "To cover general technology goals, our master certification in Deep Learning, neural modeling, and vision AI represents our elite, most flexible industry credential.";
        matchedEnrollTitle = "Artificial Intelligence & ML";
    }
    
    titleEl.innerHTML = `<i class="fa-solid fa-square-check" style="color: var(--primary-green);"></i> Recommended: ${matchedTitle}`;
    descEl.innerText = matchedDesc;
    
    actionBtn.onclick = () => {
        openEnrollmentModal(matchedEnrollTitle);
    };
    
    showToast("success", "AI matched your career profile!");
    
    if (typeof speakSpeechText === "function") {
        speakSpeechText(`We found your matching profile. We recommend: ${matchedTitle}. ${matchedDesc}`);
    }
}
