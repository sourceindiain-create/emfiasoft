/* ==================== EMF SIMULATED FLUTTER MOBILE APPLICATION ==================== */

let currentFlutterScreen = "home";
let isFlutterLoggedIn = false;

// Initialize Flutter Simulator app
function initFlutterApp() {
    flutterNav("home");
}

// Mobile Tab routing
function flutterNav(screenId) {
    currentFlutterScreen = screenId;
    
    // Update active tab buttons
    document.querySelectorAll(".phone-nav-bar .phone-nav-btn").forEach(btn => {
        btn.classList.remove("active");
    });
    
    const activeBtn = document.getElementById(`fl-btn-${screenId}`);
    if (activeBtn) activeBtn.classList.add("active");
    
    // Set phone header text
    const titleEl = document.getElementById("flutter-phone-title");
    if (screenId === "home") titleEl.innerText = "EMF Global Hub";
    else if (screenId === "chat") titleEl.innerText = "EMF Voice AI Chat";
    else if (screenId === "ocr") titleEl.innerText = "Camera OCR Scanner";
    else if (screenId === "profile") titleEl.innerText = "Student Portal Mobile";

    renderFlutterScreen();
}

// Render dynamic screens on phone frame
function renderFlutterScreen() {
    const container = document.getElementById("flutter-body-content");
    if (!container) return;
    
    container.innerHTML = "";
    
    if (currentFlutterScreen === "home") {
        // HOME SCREEN
        container.innerHTML = `
            <img src="assets/poster1.jpg" alt="Poster 1" class="fl-poster">
            
            <div class="fl-section-title">Ecosystem Support Services</div>
            <div class="fl-grid">
                <div class="fl-card" onclick="flutterNav('ocr')">
                    <i class="fa-solid fa-camera"></i>
                    <h4>OCR Scanner</h4>
                    <p>Scan crop nodes / manuals</p>
                </div>
                <div class="fl-card" onclick="flutterNav('chat')">
                    <i class="fa-solid fa-robot"></i>
                    <h4>Multilingual AI</h4>
                    <p>Hindi, English, Telugu support</p>
                </div>
            </div>

            <div class="fl-section-title">Mobile Practice Sandbox</div>
            <div class="fl-grid" style="margin-bottom: 5px;">
                <div class="fl-card" style="grid-column: 1/-1; display: flex; align-items: center; gap: 12px; background: rgba(0, 166, 81, 0.05); border-color: rgba(0, 166, 81, 0.2);" onclick="switchRole('web'); navigateTo('practice')">
                    <i class="fa-solid fa-laptop-code" style="font-size: 1.3rem; color: var(--primary-green); margin: 0;"></i>
                    <div style="text-align: left;">
                        <h4 style="margin: 0; font-size: 0.7rem;">Launch Student Labs</h4>
                        <p style="margin: 0; font-size: 0.55rem; color: var(--text-muted);">Execute JS compiler, Drone planners & pH diagnostics</p>
                    </div>
                </div>
            </div>

            <div class="fl-section-title">Trending Certifications</div>
            <div class="fl-mobile-courses-list" id="fl-courses-list">
                <!-- Dynamically loaded -->
            </div>
            
            <div class="special-offer glass-card" style="padding: 15px; margin-top: 10px; display: block; font-size: 0.7rem;">
                <h4 style="color: var(--accent-gold-dark);"><i class="fa-solid fa-gift"></i> EMF Startup Incubation</h4>
                <p>Register your idea and claim 1-Year coworking and mentoring free of cost.</p>
                <button class="enroll-btn" style="padding: 4px 10px; font-size: 0.65rem; margin-top: 8px;" onclick="claimCompanyCard()">Apply Mobile</button>
            </div>
        `;
        
        // Render 3 popular courses
        const coursesList = document.getElementById("fl-courses-list");
        if (coursesList) {
            const courses = db.getCourses().slice(0, 4);
            courses.forEach(c => {
                coursesList.innerHTML += `
                    <div class="glass-card" style="padding: 10px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h5 style="font-size: 0.75rem; margin: 0;">${c.title}</h5>
                            <span style="font-size: 0.6rem; color: var(--text-muted);">${c.duration} • ₹${c.fees.toLocaleString('en-IN')}</span>
                        </div>
                        <button class="enroll-btn" style="padding: 4px 8px; font-size: 0.6rem;" onclick="openEnrollmentModal('${c.title}')">Join</button>
                    </div>
                `;
            });
        }
        
    } else if (currentFlutterScreen === "chat") {
        // MOBILE VOICE CHATBOT VIEW
        container.innerHTML = `
            <div class="chat-controls" style="padding: 4px 0; border: none; background: transparent;">
                <select id="fl-lang-select" style="font-size: 0.65rem;" onchange="changeFlLanguage()">
                    <option value="en">English (US)</option>
                    <option value="te">Telugu (తెలుగు)</option>
                    <option value="hi">Hindi (हिन्दी)</option>
                </select>
                <button class="chat-ocr-trigger-btn" style="font-size: 0.65rem; padding: 2px 6px;" onclick="flutterNav('ocr')"><i class="fa-solid fa-camera"></i> Camera Scan</button>
            </div>
            
            <div style="flex-grow: 1; min-height: 230px; display: flex; flex-direction: column; gap: 8px; background: var(--sidebar-bg); border-radius: 12px; padding: 10px; overflow-y: auto;" id="fl-messages-container">
                <div class="message system-msg" style="font-size: 0.7rem; max-width: 90%;">
                    Hello student! Welcome to EMF Mobile Voice AI. I am trained in <strong>Telugu, Hindi, and English</strong>. Ask any academic support queries below!
                </div>
            </div>
            
            <div style="display: flex; gap: 8px; align-items: center; margin-top: 5px;">
                <input type="text" id="fl-chat-input" placeholder="Type or tap voice mic..." style="flex-grow: 1; padding: 8px 12px; border-radius: 20px; border: 1px solid var(--border-glass); font-size: 0.7rem; background: var(--input-bg); color: var(--text-main);" onkeypress="handleFlChatKeyPress(event)">
                <button class="chat-btn-circle mic-btn" id="fl-mic-btn" style="width: 32px; height: 32px; font-size: 0.8rem;" onclick="startFlVoiceInput()"><i class="fa-solid fa-microphone"></i></button>
                <button class="chat-btn-circle send-btn" style="width: 32px; height: 32px; font-size: 0.8rem;" onclick="sendFlChatMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        `;
        
    } else if (currentFlutterScreen === "ocr") {
        // CAMERA OCR SCANNER VIEW
        container.innerHTML = `
            <div class="fl-camera-view">
                <div class="fl-target-box"></div>
                <div class="fl-camera-text">
                    <i class="fa-solid fa-expand" style="font-size: 1.5rem; margin-bottom: 8px;"></i><br>
                    Align Target Document Text
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: center; margin: 10px 0;">
                <button class="btn-primary" style="padding: 8px 16px; font-size: 0.75rem;" onclick="triggerFlOcrFile()"><i class="fa-solid fa-image"></i> Gallery</button>
                <button class="btn-secondary" style="padding: 8px 16px; font-size: 0.75rem;" onclick="triggerFlOcrFile()"><i class="fa-solid fa-qrcode"></i> Capture Scan</button>
            </div>
            
            <div class="fl-ocr-result-area" id="fl-ocr-result-wrapper">
                <h4>Captured Scan Result (OCR)</h4>
                <div id="fl-ocr-status-indicator" style="font-size: 0.65rem; color: var(--text-muted); margin-bottom: 4px;">Camera standby. Select Gallery image to begin Tesseract scan.</div>
                <pre id="fl-ocr-output" style="font-size: 0.6rem; padding: 8px; background: var(--input-bg); border-radius: 6px; overflow-y: auto; max-height: 80px;">No scan captured yet.</pre>
            </div>
            
            <!-- Hidden inputs -->
            <input type="file" id="fl-ocr-file-input" class="hidden" accept="image/*" onchange="processFlOcrImage(event)">
        `;
        
    } else if (currentFlutterScreen === "profile") {
        if (!isFlutterLoggedIn) {
            container.innerHTML = `
                <div style="padding: 20px 10px; text-align: center;">
                    <div class="avatar" style="width: 55px; height: 55px; margin-bottom: 12px; background: linear-gradient(135deg, var(--primary-blue), var(--primary-green));"><i class="fa-solid fa-user-lock"></i></div>
                    <h4 style="font-size: 0.85rem; margin-bottom: 4px;">Student Account Authentication</h4>
                    <p style="font-size: 0.6rem; color: var(--text-muted); margin-bottom: 20px;">Access your mobile courses, syllabus, and verified Skill India credentials.</p>
                    
                    <div class="form-group" style="text-align: left; margin-bottom: 12px; display: flex; flex-direction: column; gap: 4px;">
                        <label style="font-size: 0.6rem; font-weight: bold;">Registered Email</label>
                        <input type="email" id="fl-auth-email" value="alex@emfi.com" style="padding: 8px 10px; font-size: 0.65rem; border-radius: 6px; border: 1px solid var(--border-glass); background: var(--input-bg); color: var(--text-main);">
                    </div>
                    <div class="form-group" style="text-align: left; margin-bottom: 20px; display: flex; flex-direction: column; gap: 4px;">
                        <label style="font-size: 0.6rem; font-weight: bold;">Secure Password</label>
                        <input type="password" id="fl-auth-pass" value="password" style="padding: 8px 10px; font-size: 0.65rem; border-radius: 6px; border: 1px solid var(--border-glass); background: var(--input-bg); color: var(--text-main);">
                    </div>
                    
                    <button class="btn-primary" style="width: 100%; padding: 10px; font-size: 0.7rem; justify-content: center;" id="fl-login-btn" onclick="processFlutterLogin()"><i class="fa-solid fa-right-to-bracket"></i> Authenticate Credentials</button>
                </div>
            `;
            return;
        }

        // STUDENT DASHBOARD MOBILE VIEW
        const activeEnrollments = db.getStudents().filter(s => s.email === currentStudent.email);
        
        container.innerHTML = `
            <div style="text-align: center; background: linear-gradient(135deg, var(--primary-blue), var(--primary-green)); color: #fff; padding: 15px; border-radius: 12px;">
                <div class="avatar" style="width: 50px; height: 50px; font-size: 1.3rem; background: rgba(255,255,255,0.2);"><i class="fa-solid fa-user-graduate"></i></div>
                <h4 style="margin: 5px 0 2px;">${currentStudent.name}</h4>
                <span style="font-size: 0.6rem; color: var(--accent-gold); font-weight: 700;">ENROLLED STUDENT</span>
                <button class="enroll-btn" style="padding: 2px 6px; font-size: 0.55rem; background: rgba(255,255,255,0.25); border: none; margin-top: 5px; color:#fff;" onclick="isFlutterLoggedIn=false; renderFlutterScreen();">Logout</button>
            </div>
            
            <div class="fl-section-title">My Mobile Classes (${activeEnrollments.length})</div>
            <div style="display: flex; flex-direction: column; gap: 8px;" id="fl-my-courses-list">
                <!-- Loaded dynamically -->
            </div>
            
            <div class="fl-section-title">Ecosystem Certifications</div>
            <div style="display: flex; flex-direction: column; gap: 8px;" id="fl-my-certs-list">
                <!-- Loaded dynamically -->
            </div>
        `;
        
        // Render dynamic courses purchased inside mobile portal
        const flCoursesList = document.getElementById("fl-my-courses-list");
        if (flCoursesList) {
            if (activeEnrollments.length === 0) {
                flCoursesList.innerHTML = `<p style="font-size:0.65rem; color: var(--text-muted); text-align:center;">No enrolled courses yet.</p>`;
            }
            activeEnrollments.forEach(enroll => {
                const cObj = db.getCourses().find(c => c.code === enroll.courseCode);
                if (cObj) {
                    flCoursesList.innerHTML += `
                        <div class="glass-card" style="padding: 10px; display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h5 style="font-size:0.7rem; margin:0;">${cObj.title}</h5>
                                <span style="font-size:0.55rem; color: var(--primary-green); font-weight:700;">Study Portal Unlocked</span>
                            </div>
                            <button class="enroll-btn" style="padding: 2px 6px; font-size:0.55rem;" onclick="openCourseSyllabus('${cObj.title}')">Study</button>
                        </div>
                    `;
                }
            });
        }
        
        // Render certificates
        const flCertsList = document.getElementById("fl-my-certs-list");
        if (flCertsList) {
            if (activeEnrollments.length === 0) {
                flCertsList.innerHTML = `<p style="font-size:0.65rem; color: var(--text-muted); text-align:center;">No certificates issued.</p>`;
            }
            activeEnrollments.forEach(enroll => {
                const cObj = db.getCourses().find(c => c.code === enroll.courseCode);
                if (cObj) {
                    flCertsList.innerHTML += `
                        <div class="glass-card" style="padding: 10px; display: flex; align-items: center; justify-content: space-between; border-left: 3px solid var(--accent-gold);">
                            <div>
                                <h5 style="font-size:0.7rem; margin:0;">${cObj.title}</h5>
                                <span style="font-size:0.55rem; color: var(--text-muted);">Verified Issue ID</span>
                            </div>
                            <button class="enroll-btn" style="padding: 2px 6px; font-size:0.55rem; background: var(--accent-gold-dark); color:#000;" onclick="downloadCert('${cObj.title}', '${currentStudent.name}')"><i class="fa-solid fa-award"></i></button>
                        </div>
                    `;
                }
            });
        }
    }
}

// Change language inside simulated phone
function changeFlLanguage() {
    const select = document.getElementById("fl-lang-select");
    if (!select) return;
    
    chatLanguage = select.value;
    
    // Synced selector in standard floating chatbot
    const webSelect = document.getElementById("chat-lang-select");
    if (webSelect) webSelect.value = chatLanguage;
    
    const welcome = OFFLINE_KNOWLEDGE[chatLanguage].welcome;
    appendFlMessage("system", welcome);
    speakSpeechText(welcome);
}

// Append mobile chat messages
function appendFlMessage(sender, text) {
    const container = document.getElementById("fl-messages-container");
    if (!container) return;
    
    const msg = document.createElement("div");
    msg.className = `message ${sender === "user" ? "user-msg" : "system-msg"}`;
    msg.style.fontSize = "0.7rem";
    msg.style.maxWidth = "90%";
    msg.innerText = text;
    
    container.appendChild(msg);
    container.scrollTop = container.scrollHeight;
}

// Send Mobile Chat message query
async function sendFlChatMessage() {
    const input = document.getElementById("fl-chat-input");
    if (!input) return;
    
    const query = input.value.trim();
    if (!query) return;
    
    appendFlMessage("user", query);
    input.value = "";
    
    const thinking = document.createElement("div");
    thinking.className = "message system-msg";
    thinking.style.fontSize = "0.7rem";
    thinking.innerText = "Analyzing mobile response...";
    document.getElementById("fl-messages-container").appendChild(thinking);
    
    try {
        const response = await queryAIChatbot(query);
        thinking.remove();
        appendFlMessage("system", response);
        speakSpeechText(response);
    } catch(err) {
        thinking.remove();
        appendFlMessage("system", "Error communicating with AI network gateway.");
    }
}

// Listen to keypress
function handleFlChatKeyPress(e) {
    if (e.key === "Enter") {
        sendFlChatMessage();
    }
}

// Start voice recognition in mobile frame
function startFlVoiceInput() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        showToast("error", "Web Speech API is not supported in this browser.");
        return;
    }
    
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    
    if (chatLanguage === "te") recognition.lang = "te-IN";
    else if (chatLanguage === "hi") recognition.lang = "hi-IN";
    else recognition.lang = "en-US";
    
    const micBtn = document.getElementById("fl-mic-btn");
    
    recognition.onstart = () => {
        micBtn.classList.add("recording");
        showToast("info", "Listening on mobile microphone...");
    };
    
    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        const inputField = document.getElementById("fl-chat-input");
        if (inputField) {
            inputField.value = transcript;
            sendFlChatMessage();
        }
    };
    
    recognition.onend = () => {
        micBtn.classList.remove("recording");
    };
    
    recognition.start();
}

// Launch Mobile file explorer
function triggerFlOcrFile() {
    const fileInput = document.getElementById("fl-ocr-file-input");
    if (fileInput) fileInput.click();
}

// Handle Mobile OCR image file selection and scan
function processFlOcrImage(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    // Create laser line sweep inside phone camera feed
    const cameraView = document.querySelector(".fl-camera-view");
    let laser = document.createElement("div");
    laser.className = "ocr-laser-line";
    if (cameraView) cameraView.appendChild(laser);
    
    const indicator = document.getElementById("fl-ocr-status-indicator");
    const output = document.getElementById("fl-ocr-output");
    
    if (indicator) indicator.innerText = "Running mobile Tesseract layout analysis...";
    if (output) output.innerText = "Processing image patterns...";
    
    Tesseract.recognize(
        file,
        chatLanguage === "te" ? "tel" : chatLanguage === "hi" ? "hin" : "eng",
        {
            logger: m => {
                if (m.status === 'recognizing text') {
                    const progress = Math.round(m.progress * 100);
                    if (indicator) indicator.innerText = `Recognizing glyphs: ${progress}%`;
                }
            }
        }
    ).then(({ data: { text } }) => {
        if (laser) laser.remove();
        const cleanedText = text.trim();
        if (indicator) indicator.innerText = "Mobile scan completed successfully!";
        if (output) output.innerText = cleanedText || "No text could be extracted.";
        
        if (cleanedText) {
            showToast("success", "Extracted OCR scanned text inside Flutter simulator!");
            
            // Redirect to chat tab automatically and prompt assistant with scanned text
            setTimeout(() => {
                flutterNav("chat");
                appendFlMessage("user", `[Mobile Camera OCR]: "${cleanedText.substring(0, 100)}..."`);
                
                const ocrPrompt = OFFLINE_KNOWLEDGE[chatLanguage].ocr_result.replace("{text}", cleanedText);
                appendFlMessage("system", ocrPrompt);
                speakSpeechText(ocrPrompt);
            }, 1200);
        }
    }).catch(err => {
        if (laser) laser.remove();
        console.error("Mobile OCR Error:", err);
        if (indicator) indicator.innerText = "OCR parser crashed.";
        if (output) output.innerText = "Failed to scan text layout.";
    });
}

// Simulated Flutter Student Authentication flow
function processFlutterLogin() {
    const email = document.getElementById("fl-auth-email").value.trim();
    const btn = document.getElementById("fl-login-btn");
    if (!email || !email.includes("@")) {
        showToast("error", "Please enter a valid student email address!");
        return;
    }
    
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin"></i> Checking Token...`;
    
    setTimeout(() => {
        btn.disabled = false;
        btn.innerHTML = originalText;
        
        // Lookup student in DB
        const students = db.getStudents();
        const found = students.find(s => s.email.toLowerCase() === email.toLowerCase());
        
        if (found) {
            currentStudent = found;
            isFlutterLoggedIn = true;
            showToast("success", `Authenticated mobile session as ${found.name}`);
            renderFlutterScreen();
        } else {
            // Register guest account dynamically
            const guest = {
                name: "Guest Innovator",
                email: email,
                phone: "+91 9898989898",
                courseCode: "IT-01",
                branch: "hyderabad",
                status: "Active",
                enrollDate: new Date().toISOString().split('T')[0]
            };
            db.saveStudent(guest);
            currentStudent = guest;
            isFlutterLoggedIn = true;
            showToast("success", `Created new guest account: ${email}`);
            renderFlutterScreen();
        }
    }, 1500);
}
