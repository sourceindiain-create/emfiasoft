/* ==================== EMF LOCAL DATABASE STORAGE ENGINE ==================== */

const DEFAULT_COURSES = [
    {
        code: "IT-01",
        title: "Data Science Specialization",
        category: "it",
        fees: 5000,
        duration: "6 Months",
        rating: 4.9,
        description: "Comprehensive data science certification covering Python, Pandas, statistical modeling, machine learning, and data visualization pipelines."
    },
    {
        code: "IT-02",
        title: "Artificial Intelligence & ML",
        category: "it",
        fees: 6500,
        duration: "6 Months",
        rating: 4.8,
        description: "Master Deep Learning, Neural Networks, TensorFlow, Computer Vision, and Natural Language Processing with live research-grade projects."
    },
    {
        code: "IT-03",
        title: "Internet of Things (IoT) Systems",
        category: "it",
        fees: 4500,
        duration: "3 Months",
        rating: 4.7,
        description: "Build real-time connected systems, sensor networking, smart home controllers, and cloud-to-device streaming pipelines."
    },
    {
        code: "TE-01",
        title: "Commercial Drone Technology",
        category: "tech",
        fees: 5500,
        duration: "3 Months",
        rating: 4.9,
        description: "Hands-on drone assembly, flight aerodynamics, telemetry programming, automated flight paths, and drone thermal solar analysis."
    },
    {
        code: "TE-02",
        title: "Solar & EV Systems Engineering",
        category: "tech",
        fees: 5000,
        duration: "3 Months",
        rating: 4.7,
        description: "Learn electric vehicle battery chemistry, solar grid synchronization, charge controllers, and next-gen sustainable power logistics."
    },
    {
        code: "TE-03",
        title: "Green Hydrogen & Biomass Energy",
        category: "tech",
        fees: 6000,
        duration: "3 Months",
        rating: 4.6,
        description: "Advanced study of hydrogen fuel cells, clean energy storage, biomass electrolysis, and micro-grid sustainable deployments."
    },
    {
        code: "AG-01",
        title: "Smart Biotech & Plant Development",
        category: "agri",
        fees: 3500,
        duration: "3 Months",
        rating: 4.8,
        description: "Modern biotechnology and botany applications: vertical microgreens systems, soil pH analysis, botany genetics, and sustainable farming."
    },
    {
        code: "AG-02",
        title: "Microbiology & Seed Innovation",
        category: "agri",
        fees: 4500,
        duration: "3 Months",
        rating: 4.7,
        description: "Advanced chemical, hydrogen, and seed projects analyzing soil-based microorganisms, plant defense mechanisms, and crop optimizations."
    },
    {
        code: "AG-03",
        title: "Urban Farming & Vertical Gardening",
        category: "agri",
        fees: 3000,
        duration: "2 Months",
        rating: 4.9,
        description: "Terrace gardening setups, organic nutrient feeding formulas, LED wavelength optimization, and home microgreen crops."
    },
    {
        code: "BU-01",
        title: "Fullstack Web & Digital Marketing",
        category: "non-it",
        fees: 3500,
        duration: "3 Months",
        rating: 4.7,
        description: "Build robust dynamic web applications using Javascript/HTML, SEO optimization, and digital campaign planning."
    },
    {
        code: "BU-02",
        title: "Tally ERP & Business Analytics",
        category: "non-it",
        fees: 3000,
        duration: "2 Months",
        rating: 4.6,
        description: "Corporate financial accounting, enterprise resource planning, database querying with SQL, and Excel analytics dashboards."
    }
];

const DEFAULT_STUDENTS = [
    {
        name: "Alex Mercer",
        email: "alex@emfi.com",
        phone: "+91 9876543210",
        courseCode: "IT-02",
        branch: "bangalore",
        status: "Active",
        enrollDate: "2026-05-10"
    },
    {
        name: "Priya Sharma",
        email: "priya@emfi.com",
        phone: "+91 9123456789",
        courseCode: "AG-01",
        branch: "hyderabad",
        status: "Active",
        enrollDate: "2026-05-18"
    },
    {
        name: "Karan Patel",
        email: "karan@emfi.com",
        phone: "+91 8888877777",
        courseCode: "TE-01",
        branch: "vijayawada",
        status: "Active",
        enrollDate: "2026-05-24"
    }
];

const DEFAULT_PAYMENTS = [
    {
        paymentId: "pay_RTX1092837",
        studentName: "Alex Mercer",
        studentEmail: "alex@emfi.com",
        courseTitle: "Artificial Intelligence & ML",
        amount: 6500,
        method: "UPI",
        timestamp: "2026-05-10 10:42 AM"
    },
    {
        paymentId: "pay_RTX9920184",
        studentName: "Priya Sharma",
        studentEmail: "priya@emfi.com",
        courseTitle: "Smart Biotech & Plant Development",
        amount: 3500,
        method: "Card",
        timestamp: "2026-05-18 02:15 PM"
    },
    {
        paymentId: "pay_RTX7761524",
        studentName: "Karan Patel",
        studentEmail: "karan@emfi.com",
        courseTitle: "Commercial Drone Technology",
        amount: 5500,
        method: "Net Banking",
        timestamp: "2026-05-24 11:30 AM"
    }
];

// Initialize Mock Database
class EMFDatabase {
    constructor() {
        this.apiBase = `${window.location.origin}/api`;
        this.online = false;
        this.init();
        this.ready = this.loadFromServer();
    }

    init() {
        if (!localStorage.getItem("emf_courses")) {
            localStorage.setItem("emf_courses", JSON.stringify(DEFAULT_COURSES));
        }
        if (!localStorage.getItem("emf_students")) {
            localStorage.setItem("emf_students", JSON.stringify(DEFAULT_STUDENTS));
        }
        if (!localStorage.getItem("emf_payments")) {
            localStorage.setItem("emf_payments", JSON.stringify(DEFAULT_PAYMENTS));
        }
        if (!localStorage.getItem("emf_settings")) {
            localStorage.setItem("emf_settings", JSON.stringify({
                geminiApiKey: "",
                whatsapp: "https://wa.me/918125016226",
                facebook: "https://www.facebook.com/EMFGlobalTechnology"
            }));
        }
    }

    getCourses() {
        return JSON.parse(localStorage.getItem("emf_courses"));
    }

    saveCourse(course) {
        const courses = this.getCourses();
        courses.push(course);
        localStorage.setItem("emf_courses", JSON.stringify(courses));
        return this.request("/courses", {
            method: "POST",
            body: JSON.stringify(course)
        });
    }

    deleteCourse(code) {
        const courses = this.getCourses().filter(c => c.code !== code);
        localStorage.setItem("emf_courses", JSON.stringify(courses));
        return this.request(`/courses/${encodeURIComponent(code)}`, {
            method: "DELETE"
        });
    }

    getStudents() {
        return JSON.parse(localStorage.getItem("emf_students"));
    }

    saveStudent(student) {
        const students = this.getStudents();
        students.push(student);
        localStorage.setItem("emf_students", JSON.stringify(students));
        return this.request("/students", {
            method: "POST",
            body: JSON.stringify(student)
        });
    }

    getPayments() {
        return JSON.parse(localStorage.getItem("emf_payments"));
    }

    savePayment(payment) {
        const payments = this.getPayments();
        payments.push(payment);
        localStorage.setItem("emf_payments", JSON.stringify(payments));
        return this.request("/payments", {
            method: "POST",
            body: JSON.stringify(payment)
        });
    }

    getSettings() {
        return JSON.parse(localStorage.getItem("emf_settings"));
    }

    saveSettings(settings) {
        localStorage.setItem("emf_settings", JSON.stringify(settings));
        return this.request("/settings", {
            method: "PUT",
            body: JSON.stringify(settings)
        });
    }

    saveContact(contact) {
        return this.request("/contacts", {
            method: "POST",
            body: JSON.stringify(contact)
        });
    }

    async request(path, options = {}) {
        try {
            const response = await fetch(`${this.apiBase}${path}`, {
                headers: {
                    "Content-Type": "application/json",
                    ...(options.headers || {})
                },
                ...options
            });

            if (!response.ok) {
                const payload = await response.json().catch(() => ({}));
                throw new Error(payload.error || `Request failed with ${response.status}`);
            }

            this.online = true;
            return response.json().catch(() => null);
        } catch (error) {
            this.online = false;
            console.warn("EMF API sync failed; using local cache.", error);
            return null;
        }
    }

    async loadFromServer() {
        const payload = await this.request("/bootstrap");
        if (!payload) return false;

        localStorage.setItem("emf_courses", JSON.stringify(payload.courses || DEFAULT_COURSES));
        localStorage.setItem("emf_students", JSON.stringify(payload.students || DEFAULT_STUDENTS));
        localStorage.setItem("emf_payments", JSON.stringify(payload.payments || DEFAULT_PAYMENTS));
        localStorage.setItem("emf_settings", JSON.stringify(payload.settings || this.getSettings()));
        return true;
    }
}

// Global instance
const db = new EMFDatabase();
