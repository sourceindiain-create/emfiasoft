/* ==================== EMF RAZORPAY & SECURE CHECKOUT GATEWAY ==================== */

let activePaymentDetails = null;
let selectedMethod = "upi";

// Launch Secured Razorpay Checkout Mock Modal
function triggerRazorpayPayment(data) {
    activePaymentDetails = data;
    
    // Set UI displays
    document.getElementById("rp-payment-purpose").innerText = `Enrollment Fee: ${data.courseTitle}`;
    document.getElementById("rp-pay-amount").innerText = `₹${data.fees.toLocaleString('en-IN')}`;
    document.getElementById("btn-rp-pay-amount").innerText = `₹${data.fees.toLocaleString('en-IN')}`;
    document.getElementById("rp-user-email").innerText = data.email;
    document.getElementById("rp-user-phone").innerText = data.phone;
    
    // Default input selectors
    selectPaymentMethod("upi");
    
    // Show Modal Overlay
    document.getElementById("payment-modal").classList.add("active");
    showToast("info", "Opening secure Razorpay checkout panel...");
}

// Close payment modal
function closePaymentModal() {
    document.getElementById("payment-modal").classList.remove("active");
    showToast("error", "Secure checkout transaction cancelled by user.");
    activePaymentDetails = null;
}

// Select Checkout payment tab row
function selectPaymentMethod(method) {
    selectedMethod = method;
    
    // Highlight active row
    document.querySelectorAll(".rp-method-row").forEach(row => {
        row.classList.remove("active");
        row.querySelector("input[type='radio']").checked = false;
    });
    
    // Active group panels
    document.querySelectorAll(".rp-input-group").forEach(group => {
        group.classList.remove("active");
    });
    
    let targetRow = null;
    if (method === "upi") {
        targetRow = document.querySelector(".rp-method-row:nth-child(2)"); // UPI is first in list (th:2 because of h4 title)
        document.getElementById("rp-input-upi").classList.add("active");
    } else if (method === "card") {
        targetRow = document.querySelector(".rp-method-row:nth-child(3)");
        document.getElementById("rp-input-card").classList.add("active");
    } else if (method === "netbank") {
        targetRow = document.querySelector(".rp-method-row:nth-child(4)");
        document.getElementById("rp-input-netbank").classList.add("active");
    }
    
    if (targetRow) {
        targetRow.classList.add("active");
        targetRow.querySelector("input[type='radio']").checked = true;
    }
}

// Process mock payment API
function processMockPayment() {
    if (!activePaymentDetails) return;
    
    // Inputs validation
    if (selectedMethod === "upi") {
        const upiVal = document.getElementById("rp-upi-id").value;
        if (!upiVal || !upiVal.includes("@")) {
            showToast("error", "Please enter a valid UPI address (e.g. user@upi)");
            return;
        }
    } else if (selectedMethod === "card") {
        const cardNum = document.getElementById("rp-card-number").value;
        if (cardNum.length < 16) {
            showToast("error", "Please enter a valid 16-digit credit card number.");
            return;
        }
    }
    
    const payBtn = document.querySelector(".btn-rp-pay");
    const originalText = payBtn.innerHTML;
    
    // Replicate transaction verification loading spinner
    payBtn.disabled = true;
    payBtn.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin"></i> Verifying OTP & Funds...`;
    
    setTimeout(() => {
        // Build mock payment metadata
        const payId = `pay_EMF_RTX${Math.floor(10000000 + Math.random() * 90000000)}`;
        const timestamp = getFormattedTimestamp();
        
        // Save records to database
        const newStudent = {
            name: activePaymentDetails.name,
            email: activePaymentDetails.email,
            phone: activePaymentDetails.phone,
            courseCode: activePaymentDetails.courseCode,
            branch: activePaymentDetails.branch,
            status: "Active",
            enrollDate: new Date().toISOString().split('T')[0]
        };
        
        const newPayment = {
            paymentId: payId,
            studentName: activePaymentDetails.name,
            studentEmail: activePaymentDetails.email,
            courseTitle: activePaymentDetails.courseTitle,
            amount: activePaymentDetails.fees,
            method: selectedMethod.toUpperCase(),
            timestamp: timestamp
        };
        
        // Save
        db.saveStudent(newStudent);
        db.savePayment(newPayment);
        
        // Reset states
        payBtn.disabled = false;
        payBtn.innerHTML = originalText;
        document.getElementById("payment-modal").classList.remove("active");
        
        // Display premium invoice toast
        showToast("success", `Secure payment success! Enrolled in ${activePaymentDetails.courseTitle}`);
        
        // Automatically set current session user to enrolled student to showcase student portal dashboard
        currentStudent = newStudent;
        
        // Refresh grids and dashboards
        refreshDashboards();
        
        // Redirect to student portal automatically to showcase immediate enrollment reflection!
        setTimeout(() => {
            switchRole("student");
            showToast("info", "Welcome to EMF Student Portal. Access your study syllabus below!");
        }, 800);
        
        activePaymentDetails = null;
        
    }, 2200);
}

// Generate simple human-readable timestamp
function getFormattedTimestamp() {
    const d = new Date();
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const year = d.getFullYear();
    const month = months[d.getMonth()];
    const date = d.getDate();
    
    let hours = d.getHours();
    let minutes = d.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    
    return `${month} ${date}, ${year} ${hours}:${minutes} ${ampm}`;
}
