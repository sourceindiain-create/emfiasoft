const CACHE_NAME = "emf-global-v1";
const APP_SHELL = [
  "/",
  "/index.html",
  "/styles.css",
  "/mock-db.js",
  "/app.js",
  "/ai-chatbot.js",
  "/payment-gateway.js",
  "/flutter-simulator.js",
  "/assets/logo.jpg",
  "/assets/poster1.jpg",
  "/assets/poster2.jpg",
  "/site.webmanifest"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
    )
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) {
        return cached;
      }

      return fetch(event.request).catch(() => caches.match("/index.html"));
    })
  );
});
